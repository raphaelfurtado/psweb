<?php

namespace App\Controllers;

class HelloWorld extends BaseController
{
    public function index()
    {
        echo '<h1>Heloooooooo</h1>';
    }
}
