</main>
<footer class="bg-gray-800 text-white text-center py-4">
    <p class="text-sm">
        Feito por
        <a href="https://softbean.com" target="_blank" class="text-primary hover:underline">
            Softbean
        </a>
    </p>
</footer>